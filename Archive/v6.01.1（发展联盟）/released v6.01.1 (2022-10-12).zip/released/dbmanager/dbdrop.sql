drop table qualiResult;
drop table raceResult;
drop table raceDirector;
drop table driverLeaderBoard;
drop table driverTransfer;
drop table raceCalendar;
drop table driverList;
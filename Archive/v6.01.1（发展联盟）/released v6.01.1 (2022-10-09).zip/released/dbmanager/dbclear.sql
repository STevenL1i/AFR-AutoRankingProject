delete from qualiResult;
delete from raceResult;
delete from raceDirector;
delete from driverLeaderBoard;
delete from driverTransfer;
delete from raceCalendar;
delete from driverList;